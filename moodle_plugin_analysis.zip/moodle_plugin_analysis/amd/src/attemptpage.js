define(['jquery', 'core/ajax', 'core/notification'],
    function ($) {
        return {
            setup: function (props) {
                var quizurl = props.quizurl;

                /**
                 * Closes attempt page upon parent window close.
                 */
                /**
                 * Closes attempt page upon parent window close.
                 */
                function CloseOnParentClose() {
                    try {
                        // Check if opener exists and is not closed
                        if (typeof window.opener == 'undefined' || window.opener === null || window.opener.closed) {
                            // window.close();
                            return;
                        }

                        // DOM access might fail if cross-origin, wrap in try-catch
                        var openerDoc = window.opener.document;
                        if (!openerDoc) {
                            // If we can't access the document (e.g. cross-origin), we probably shouldn't be here or can't verify.
                            // Safest to keep open or let Moodle session handle it.
                            return;
                        }

                        // Check URL compatibility (optional: relax to just same origin check if needed)
                        // Using try-catch around location access is best practice
                        try {
                            if (window.opener.location.host !== window.location.host) {
                                // Cross-origin opener? Suspicious.
                                // window.close(); 
                                // Commented out to be less aggressive, let Moodle auth handle access.
                            }
                        } catch (e) {
                            // Permission denied to access location
                        }

                        // Get elements directly from the opener's document
                        var shareStateElem = openerDoc.getElementById('invigilator_share_state');
                        var windowSurfaceElem = openerDoc.getElementById('invigilator_window_surface');

                        // If elements aren't there, the opener might not be the right page
                        if (!shareStateElem || !windowSurfaceElem) {
                            return;
                        }

                        var shareState = shareStateElem.value;
                        var windowSurface = windowSurfaceElem.value;

                        // CRITICAL FIX: Treat empty strings as "initializing" - do not close!
                        // Only close if we explicitly have a failure state.

                        // If logic requires explicit "true" to stay open, wait for it.
                        // But if it starts as "", we must not close immediately.
                        if (shareState !== "" && shareState !== "true") {
                            // window.close();
                        }

                        if (windowSurface !== "" && windowSurface !== 'monitor') {
                            // window.close();
                        }

                    } catch (err) {
                        // If any security error occurs accessing opener, user might be in a constrained env.
                        // Ideally log this, but avoiding window.close() prevents accidental lockouts.
                        // console.error(err);
                    }
                }
                $(window).ready(function () {
                    setInterval(CloseOnParentClose, 1000);
                });
                return true;
            },
            init: function () {
                return true;
            }
        };
    });
